import UIKit

//MARK: -
enum EngineState: String {
    case on = "заведен", off = "заглушен"
}

enum WindowState: String {
    case open = "открыты", close = "закрыты"
}

enum DoorState: String {
    case open = "открыты", close = "закрыты"
}

enum RoofState: String {
    case installed = "установленна", removed = "убрана"
}

enum TrunkState: String {
    case full = "полная", half = "заполнена на половину", empty = "пустая"
}

protocol Car: class, CustomStringConvertible {
    var mark: String { get }
    var year: Int { get }
    var km: Double { get set }
    var vehicleWeight: Double { get set }
    var engineState: EngineState { get set }
    var windowState: WindowState { get set }
    var doorState: DoorState { get set }

    func changeWindowState(to: WindowState)
    func changeEngineState(to: EngineState)
    func changeDoorState(to: DoorState)
}

extension Car {
    func changeWindowState(to: WindowState) {
        windowState = to
    }
    
    func changeEngineState(to: EngineState) {
        engineState = to
    }
    
    func changeDoorState(to: DoorState) {
        doorState = to
    }
    
    var description: String {
        return "Марка автомобиля: \(mark), год выпуска: \(year),пробег: \(km), вес автомобиля: \(vehicleWeight), состояние двигателя: \(engineState.rawValue), состояниеокон:\(windowState.rawValue), состояние дверей: \(doorState.rawValue)"
    }
}

class SprotCar: Car {
    var mark: String
    var year: Int
    var km: Double
    var vehicleWeight: Double
    var engineState: EngineState
    var windowState: WindowState
    var doorState: DoorState
    var roofState: RoofState
    
    init(mark: String, year: Int, km: Double,
         vehicleWeight: Double, engineState: EngineState,
         windowState: WindowState, doorState: DoorState,
         roofState: RoofState) {
      
        self.mark = mark
        self.year = year
        self.km = km
        self.vehicleWeight = vehicleWeight
        self.engineState = engineState
        self.windowState = windowState
        self.doorState = doorState
        self.roofState = roofState
    }
    func changeRoofState(to: RoofState) {
        roofState = to
    }
}

class TrunkCar: Car {
    let mark: String
    var year: Int
    var km: Double
    var vehicleWeight: Double
    var engineState: EngineState
    var windowState: WindowState
    var doorState: DoorState
    var trunkState: TrunkState
    
    func changeYear(to newYear: Int) {
        self.year = newYear
    }
    init(mark: String, year:Int, km: Double,
         vehicleWeight: Double, engineState: EngineState,
         windowState: WindowState, doorState: DoorState,
         trunkState: TrunkState) {
        
        self.mark = mark
        self.year = year
        self.km = km
        self.vehicleWeight = vehicleWeight
        self.engineState = engineState
        self.windowState = windowState
        self.doorState = doorState
        self.trunkState = trunkState
    }
    
    func changeTrunkState(to: TrunkState) {
        trunkState = to
    }
}

extension SprotCar {
    var description: String {
        return "Марка автомобиля: \(mark), год выпуска: \(year), пробег: \(km), вес автомобиля: \(vehicleWeight), состояние двигателя: \(engineState.rawValue), состояние окон: \(windowState.rawValue), состояние дверей: \(doorState.rawValue), состояние крыши: \(roofState.rawValue)"
    }
}

extension TrunkCar {
    var description: String {
        "Марка автомобиля: \(mark), год выпуска: \(year),пробег: \(km), вес автомобиля: \(vehicleWeight), состояние двигателя: \(engineState.rawValue), состояние окон:\(windowState.rawValue), состояние дверей: \(doorState.rawValue), объем богажника: \(trunkState.rawValue)"
    }
 }

var car1 = SprotCar(mark: "BMW M5", year: 2020, km: 0, vehicleWeight: 1850, engineState: .off, windowState: .close, doorState: .close, roofState: .removed)

var car2 = SprotCar(mark: "WW Golf", year: 2019, km: 1000, vehicleWeight: 1670, engineState: .on, windowState: .open, doorState: .open, roofState: .installed)

var car3 = TrunkCar(mark: "Kamaz", year: 2019, km: 1000, vehicleWeight: 6180, engineState: .off, windowState: .close, doorState: .close, trunkState: .empty)

var car4 = TrunkCar(mark: "MAN", year: 2020, km: 0, vehicleWeight: 7100, engineState: .off, windowState: .close, doorState: .close, trunkState: .full)

car3.changeYear(to: 2021)
car1.changeEngineState(to: .on)
car2.changeDoorState(to: .open)
car3.changeTrunkState(to: .half)

func lineBreakPrint (_ value: Any) {
    print(value, "\n")
}

lineBreakPrint(car1)
lineBreakPrint(car2)
lineBreakPrint(car3)
lineBreakPrint(car4)
