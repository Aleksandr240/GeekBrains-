import UIKit

//MARK: -
enum EngineState {
    case on, off
}

enum WindowState: String {
    case open = "открыто", close = "закрыто"
}

enum DoorState {
    case open, close
}

enum Roof {   //Откидная крыша спорткара: установлена, убрана
    case installed, removed
}

enum Trunk {  //Кузов самосвала: поднят, опущен
    case up, down
}
// MARK: -
class Car {
    
    let mark: String
    let year: Int
    var km: Double
    var vehicleWeight: Double
    var engineState: EngineState
    var windowState: WindowState
    var doorState: DoorState
    
    
    
init(mark: String, year: Int, km: Double,
         vehicleWeight: Double,
         engineState: EngineState,
         windowState: WindowState,
         doorState: DoorState) {

        self.mark = mark
        self.year = year
        self.km = km
        self.vehicleWeight = vehicleWeight
        self.engineState = engineState
        self.windowState = windowState
        self.doorState = doorState
    }
    
            //Добавил пустые методы
    
    func changeEngineState(to: EngineState) {}
    func changeWindowsState(to: WindowState) {}
    func changeDoorState(to: DoorState) {}
    
    func printDetail() {
        print(self.windowState.rawValue)
    }
    
}
//MARK: -

class SportCar: Car {
    
    var roof: Roof
    
     init(mark: String, year: Int, km: Double,
                  vehicleWeight: Double,
                  engineState: EngineState,
                  windowState: WindowState,
                  doorState: DoorState,
                  roof: Roof) {
    
        self.roof = roof
        
        super.init(mark: mark, year: year, km: km,
                   vehicleWeight: vehicleWeight,
                   engineState: engineState,
                   windowState: windowState,
                   doorState: doorState )
    }
    func changeRoofState(to: Roof) {
        roof = to
    }
   
    //Добавим сигнализацию спорткару
    
    func alarmOFF() {
        engineState = .on
        windowState = .open
        doorState = .open
    }
    
    func alarmON() {
        engineState = .off
        windowState = .close
        doorState = .close
        
    }
    override func changeWindowsState(to: WindowState) {
        windowState = to
        
    }
    override func changeEngineState(to: EngineState) {
        engineState = to
        
    }
    override func changeDoorState(to: DoorState) {
        doorState = to
        
    }
}

class TrunkCar: Car {
    var trunk: Trunk
   
    init(mark: String, year: Int, km: Double,
        vehicleWeight: Double,
         engineState: EngineState,
        windowState: WindowState,
         doorState: DoorState,
        trunk: Trunk) {
    
        self.trunk = trunk
        
    super.init(mark: mark, year: year, km: km,
                vehicleWeight: vehicleWeight,
                engineState: engineState,
                windowState: windowState,
                doorState: doorState)
    }
    func changeTrunkState(to: Trunk) {
        trunk = to
    }
    override func changeWindowsState(to: WindowState) {
        windowState = to
        
    }
    override func changeEngineState(to: EngineState) {
        engineState = to
        
    }
    override func changeDoorState(to: DoorState) {
        doorState = to
        
    }
    override func printDetail() {
        super.printDetail()
        print(self.trunk)
    }
}
//MARK: -

var car1 = SportCar(mark: "Toyota GT86", year: 2020, km: 0,
                    vehicleWeight: 1222, engineState: .off,
                    windowState: .close,
                    doorState: .close, roof:.removed)

var car2 = SportCar(mark: "WW Golf", year: 2000, km: 10000.57,
                    vehicleWeight: 1229, engineState: .off,
                    windowState: .open,
                    doorState: .open, roof:.installed)

var car3 = TrunkCar(mark: "Kamaz", year: 2020, km: 1000,
                    vehicleWeight: 6180, engineState: .off,
                    windowState: .close, doorState: .close,
                    trunk: .down)

var car4 = TrunkCar(mark: "MAN", year: 2020, km: 0,
                    vehicleWeight: 7100, engineState: .on,
                    windowState: .open, doorState: .open,
                    trunk: .up)
//MARK: - Car1

car1.windowState.rawValue
car1.engineState
car1.doorState

car1.alarmOFF()

car1.windowState
car1.engineState
car1.doorState

car1.printDetail()
//MARK: - Car2
car2.roof
car2.changeRoofState(to: .removed)
car2.roof

car2.printDetail()
//MARK: - Car3
car3.doorState
car3.trunk
car3.changeDoorState(to: .open)
car3.changeTrunkState(to: .down)
car3.doorState
car3.trunk

car3.printDetail()
//MARK: - Car4
car4.trunk
car4.km
car4.changeTrunkState(to: .down)
car4.km = 100
car4.trunk
car4.km

car4.printDetail()
