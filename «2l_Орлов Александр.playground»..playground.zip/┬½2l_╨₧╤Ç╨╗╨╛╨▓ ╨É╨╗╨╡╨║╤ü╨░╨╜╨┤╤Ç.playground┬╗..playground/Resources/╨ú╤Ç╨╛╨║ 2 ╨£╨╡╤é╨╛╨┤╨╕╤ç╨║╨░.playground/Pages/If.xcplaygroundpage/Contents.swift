//: [Previous](@previous)

import Foundation

//: ## Конструкция if
/*:
    if condition {
        some code
    }
 
*/

print("- КОНСТРУКЦИЯ if")

var someNumber = 10

if someNumber < 4 {
    print("Условие верно")
}

someNumber = 1

if someNumber < 4 {
    print("Условие верно")
}

/*:
    if conditionOne {
        some code
    } else if conditionTwo {
        some code
    }
*/

print("- КОНСТРУКЦИЯ else if")

someNumber = 10

if someNumber < 4 {
    print("Первое условие верно")
} else if someNumber < 8 {
    print("Второе условие верно")
}

someNumber = 7

if someNumber < 4 {
    print("Первое условие верно")
} else if someNumber < 8 {
    print("Второе условие верно")
}

someNumber = 1

if someNumber < 4 {
    print("Первое условие верно")
} else if someNumber < 8 {
    print("Второе условие верно")
}


/*:
    if conditionOne {
        some code
    } else if conditionTwo {
        some code
    } else {
        some code
    }
 */

print("- КОНСТРУКЦИЯ if else")

someNumber = 10

if someNumber < 4 {
    print("Первое условие верно")
} else if someNumber < 8 {
    print("Второе условие верно")
} else if someNumber < 10 {
    print("Третье условие верно")
} else {
    print("Нет верных условий")
}

if someNumber < 4 {
    print("Первое условие верно")
} else if someNumber < 8 {
    print("Второе условие верно")
} else if someNumber <= 10 {
    print("Третье условие верно")
} else {
    print("Нет верных условий")
}

//: ### Тернарный оператор

print("- ТЕРНАРНЫЙ ОПЕРАТОР")

// condition ? some code : some code

var a = 7
var b = 1
var c = 5

if a > 10 {
    print("Первое условие верно")
} else {
    print("Условие не верно")
}

a < 10 ? print("Первое условие верно") : print("Условие не верно")

if a < 10 {
    c = a - b
} else {
    c = a + b
}

c = a < 10 ? a - b : a + b

//: [Next](@next)
