//: [Previous](@previous)

import Foundation

//: ## Функции

/*:
 
    func nameOfFunction() {
        some code
    }
 
 */

var a = 3

func additionalOfTwoNumbers() {
    let a = 5
    let b = 2
    let c = a + b
    
    print(c)
}

additionalOfTwoNumbers()

//: ### Функции с возвращаемыми значениями

/*:
    func nameOfFunction() -> Data Type {
        some code
        return some value
    }
 
 */

func addingTwoNumbers() -> Int {
    let a = 3
    let b = 2
    
    return a + b
}

var result = addingTwoNumbers()
var function = addingTwoNumbers
print(result)

//: ### Функции с параметрами

/*:
    func name(argumentOne parameterOne: Data Type, argumentTwo parameterTwo: Data Type) {
        some code
    }
 */
// С аргументами
func addTwoNumbers(numberOne a: Int, numberTwo b: Int) -> Int {
    return a + b
}

result = addTwoNumbers(numberOne: 4, numberTwo: 6)

func addTwoNumbersCopy(numberOne: Int, numberTwo: Int) -> Int {
    return numberOne + numberTwo
}

result = addTwoNumbersCopy(numberOne: 5, numberTwo: 8)

func additionTwoNumbers(_ numberOne: Int, _ numberTwo: Int) -> Int {
    return numberOne + numberTwo
}

result = additionTwoNumbers(10, 12)

// Обычно применяют этот вариант
func additionTwoNumbersCopy(_ numberOne: Int, and numberTwo: Int) -> Int {
    return numberOne + numberTwo
}

result = additionTwoNumbersCopy(13, and: 15)

//: [Next](@next)
