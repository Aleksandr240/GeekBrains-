//: [Previous](@previous)

import Foundation

//: ## Switch statement

/*:
    switch значение для сопоставления {
    case значение 1:
        инструкция для первого значения
    case значение 2, значение 3:
        инструкция для второго и третьего значения
    default:
        инструкция, если совпадений с шаблонами не найдено
    }
*/

let someCharacter: Character = "B"
let letter = "a"

switch someCharacter {
case "A":
    print("Is an A")
case "B":
    print("Is an B")
case "C":
    print("Is an C")
default:
    print("Неизвестная буква")
}

switch someCharacter {
case "a", "A":
    print("Is an A")
case "b", "B":
    print("Is an B")
case "c", "C":
    print("Is an C")
default:
    print("Неизвестная буква")
}

switch someCharacter {
case "a", "A":
    print("Is an A")
    fallthrough
case "b", "B":
    print("Is an B")
    fallthrough
case "c", "C":
    print("Is an C")
default:
    break
}

switch someCharacter {
case "A" where letter == "a":
    print("Is an A")
case "B" where letter == "b":
    print("Is an B")
case "C" where letter == "c":
    print("Is an C")
default:
    print("Неизвестная буква")
}


//: [Next](@next)
