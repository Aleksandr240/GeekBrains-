import Foundation

//: ## Базовые операторы
//: ### Арифметичские операторы:

var a = 9
var b = 4

a + b
a - b
a * b
a / b


//: ### Остаток от деления

a % b // a = (b * множитель) + остаток: 9 = (4 * 2) + 1
-a % b

//: ### Присваивание

a = b
let c = a + b

a += b // a = a + b
a -= b
a *= b
a /= b

//: ### Строки и символы
//: ### Конкатенация строк

let swift = "Swift"
let language = "Язык программирования"

var message = swift + " это " + language + ". "
var xCode = "Для практики нужен Xcode"

message += xCode

let exclamationMark: Character = "!"
xCode.append(exclamationMark)

//: ### Интерполяция строк

let lessonNumber = 2
let numberOfLessons = 8

let aboutCourse = """
Мы изучаем курс "Основы языка \(swift)"
Сейчес у нас урок номер \(lessonNumber).
До окончания курса осталось \(numberOfLessons - lessonNumber) уроков.
"""
print(aboutCourse)


//: ### Сравнение

a == b
a != b
a > b
a < b
a <= b
a >= b
//: ### Оператор логического НЕ

let accesDeniedMessage = "ACCESS DENIED"
let welcomeMessage = "Welcome!"

let allowedEntry = false

if allowedEntry == false {
    print(accesDeniedMessage)
}

if !allowedEntry {
    print(accesDeniedMessage)
}
//: ### Оператор логического И

let enteredDoorCode = true
let passedRetinaScan = false

if enteredDoorCode == true && passedRetinaScan == true {
    print(welcomeMessage)
} else {
    print(accesDeniedMessage)
}

if enteredDoorCode && passedRetinaScan {
    print(welcomeMessage)
} else {
    print(accesDeniedMessage)
}

//: ### Оператор логического ИЛИ

let hasDoorKey = false
let knowsOverridePassword = true

if hasDoorKey || knowsOverridePassword {
    print(welcomeMessage)
} else {
    print(accesDeniedMessage)
}

if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsOverridePassword {
    print(welcomeMessage)
} else {
    print(accesDeniedMessage)
}

//: [Next](@next)
