//: [Previous](@previous)

import Foundation

//: ## For-in циклы

/*:
 
    for counter in lower…upper {
        some code
    }
 
 */

for index in 1...5 {
    print(index)
}

for _ in 1...5 {
    print("Hello!")
}

var sum = 0

for index in 1...5 {
    sum += index
}
print(sum)

print("- stride to")

for index in stride(from: 0, to: 4, by: 2) {
    print(index)
}

print("- stride through")

for index in stride(from: 0, through: 4, by: 2) {
    print(index)
}

print("- where")

let numbers = [10, 12, 23]

for element in numbers where element.isMultiple(of: 2) {
    print(element)
}


//: [Next](@next)
