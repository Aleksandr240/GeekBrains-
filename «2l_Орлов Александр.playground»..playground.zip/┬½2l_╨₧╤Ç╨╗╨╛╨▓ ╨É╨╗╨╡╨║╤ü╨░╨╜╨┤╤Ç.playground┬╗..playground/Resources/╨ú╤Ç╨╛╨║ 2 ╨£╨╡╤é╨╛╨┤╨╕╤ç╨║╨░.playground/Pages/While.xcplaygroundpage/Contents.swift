//: [Previous](@previous)

import Foundation

//: ## While циклы

/*:
 
    while condition {
        some code
    }
 
 */

var counter = 5

while counter > 0 {
    print(counter)
    counter -= 1
}

counter = -5

while counter > 0 {
    print(counter)
    counter -= 1
}

/*:
 
    repeat {
        some code
    } while condition
 
 */

counter

print("- repeat while")

repeat {
    print("repeat:", counter)
    counter -= 1
} while counter > 0

counter

//: [Next](@next)
