import UIKit

var greeting = "Hello, playground"
// MARK: - Задание 1
// Задание 1 " Написать функцию, которая определяет, четное число или нет."
func isEvenNumber (number: Int) -> Bool { number % 2 == 0 }

// MARK: - Задание 2
// Задание 2 "Написать функцию, которая определяет, делится ли число без остатка на 3 "
func isNumber (_ number: Int, dividedBy divider: Int) -> Bool {
    return number % divider == 0
}
// MARK: - Задание 3
// Задание 3 "Создать возрастающий массив из 100 чисел."
var someArrey = [Int] ()

for i in 1...100 {
    someArrey.append(i)
}
var otherArray = [1...100]

// MARK: - Задание 4
//"Удалить из этого массива все четные числа и все числа, которые не делятся на 3."
for item in someArrey {
    if isEvenNumber(number:item ) || !isNumber(item , dividedBy: 3) {
        if let index = someArrey.firstIndex (of: item) {
            someArrey.remove(at: index)
        }
    }
}

print(someArrey)
print("\n\n--------------------------------------")

// MARK: - Задание 5
// Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 50 элементов.
 
typealias FibonacciType = Decimal
var fibonacci = [FibonacciType]()
func createNextFibonacciNumber(for array: inout [FibonacciType]) {
   
    switch array.count {
    case 0, 1:
        array.append(1)
    default:
        let penultimateNumber = array[array.count - 2]
        let lastNumber = array[array.count - 1]
        array.append(penultimateNumber + lastNumber)
    }
}
    
for _ in 1...50 {
    createNextFibonacciNumber(for: &fibonacci)
}


print (fibonacci)
print("\n\n---------------------------------")

// MARK: - Задание 6
//Заполнить массив из 100 элементов различными простыми числами

func createPrimeNumbersArray () -> [Int] {
    var primeNumbersArray = [2]
    var currentNumber = 3
    
    while primeNumbersArray.count < 100 {
        
        var isPrimeNumber = true
        for checkNumber in 2...currentNumber - 1 {
            if currentNumber % checkNumber == 0 {
                isPrimeNumber = false
                break
            }
        }
        if isPrimeNumber {
            primeNumbersArray.append(currentNumber)
        }
        currentNumber += 1
    }
    return primeNumbersArray
}
let primeNumbersArray = createPrimeNumbersArray()

print(primeNumbersArray)
print()
