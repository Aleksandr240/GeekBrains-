import UIKit
import Foundation

// MARK: - 1.

struct Money {
    var amount: Decimal
    var currency: String
}

extension Money: CustomStringConvertible {
    var description: String { "\(amount) \(currency)" }
}

enum BankAccountError: Error {
    case insufficientAmount
    case convertionError(providedCurrency: String, accountCurrency: String)
    case fraudWarning
    
    var localizedDescription: String {
        switch self {
        case .insufficientAmount:
            return "Недостаточно средств на счёте"
        case .convertionError(let provided, let supported):
            return "Ошибка вывода средств в \(provided). Валюта счета: \(supported)"
        case .fraudWarning:
            return "При следующей попытке обмануть банк , карта будет заблокированна"
        }
    }
}

extension BankAccountError: CustomStringConvertible {
    var description: String { self.localizedDescription }
}

class BankAccount {
    var balance: Money
    
    init(initialBalance: Money) {
        balance = initialBalance
    }
    
    func deposit(money: Money) -> BankAccountError? {
        guard money.amount > 0 else { return BankAccountError.fraudWarning }
        
        guard money.currency == balance.currency else {
            return BankAccountError.convertionError(
                providedCurrency: money.currency,
                accountCurrency: balance.currency)
        }
        balance.amount += money.amount
        return nil
    }
    
    func withdraw(amount: Decimal) -> (amount: Money?, error: BankAccountError?) {
        guard amount > 0 else { return (amount: nil, error: BankAccountError.fraudWarning)}
        
        guard amount <= balance.amount else {
            return ( amount: nil, error: BankAccountError.insufficientAmount)
        }
      
        balance.amount -= amount
        
        return ( amount: Money(amount: amount, currency: balance.currency), error: nil)
    }
}

extension BankAccount: CustomStringConvertible {
    var description: String {
        "Состояние счета: \(balance)"
    }
}

var account = BankAccount(initialBalance: Money(amount: 1000.0, currency: "RUB"))
if let error = account.deposit(money: Money(amount: -100, currency: "RUB")) {
    print("Внимательно \(error)")
} else {
    print(account)
}


// MARK: - 2.

extension BankAccount {
    func unsafeDeposit(money: Money) throws {
        guard money.amount > 0 else {
            throw BankAccountError.fraudWarning
        }
        
        guard money.currency == balance.currency else {
            throw BankAccountError.convertionError(
                providedCurrency: money.currency,
                accountCurrency: balance.currency)
            
        }
        balance.amount += money.amount
    }
    func usafeWithdraw(amount: Decimal) throws -> Money {
        guard amount > 0 else { throw BankAccountError.fraudWarning }
        
        guard amount <= balance.amount else { throw BankAccountError.insufficientAmount }
        
        balance.amount -= amount
        
        return Money(amount: amount, currency: balance.currency)
    }
}

do {
    let money = try account.usafeWithdraw(amount: 1200.0)
    print("Снял денег: \(money)")
} catch let error {
    print(error)
}

do {
    let newAmount = Money(amount: 1000, currency: "EU")
    try account.unsafeDeposit(money: newAmount)

} catch BankAccountError.fraudWarning {
    print("Об инциденте будет доложено")

} catch BankAccountError.convertionError(let provided, let supported) {
    print("Разные валюты: \(supported) и \(provided)!")

} catch let error {
    print(error.localizedDescription)
}
