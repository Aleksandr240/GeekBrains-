import UIKit
import Darwin
// MARK: -
enum Gender: String {
    case male = "Мужской"
    case female = "Женский"
}

class Profile {
    let gender: Gender
    let name: String
    let age: Int
    
    init(gender: Gender, name: String, age: Int) {
        self.gender = gender
        self.name = name
        self.age = age
    }
}

extension Profile {
    var toText: String {
        """
        ------------------------------------------------------
        Пол: \(gender.rawValue). Имя: \(name). Возраст: \(age)
        ------------------------------------------------------
        """
    }
}
    
// MARK: -
    struct Queue<T> {
    private var elements: [T] = []
    
    func filter(predicate: (T) -> Bool) -> [T] {
        var tempArray: [T] = []
        for element in elements {
            if predicate(element) {
                tempArray.append(element)
            }
        }
        return tempArray
    }
    mutating func push (element: T) {
        elements.append(element)
    }
    mutating func pop() -> T? {
        guard elements.count > 0 else {return nil}
        return elements.removeFirst()
    }
}
// MARK: -
extension Queue {
    subscript(index: Int) -> T? {
        guard index >= 0 && index < elements.count else {
            return nil
        }
        return elements[index]
    }
}


var profiles = Queue<Profile>()

profiles.push(element: Profile(gender: .male, name: "Евгений", age: 22))
profiles.push(element: Profile(gender: .female, name: "Екатерина", age: 15))
profiles.push(element: Profile(gender: .male, name: "Борис", age: 32))
profiles.push(element: Profile(gender: .male, name: "Вячеслав", age: 13))
profiles.push(element: Profile(gender: .female, name: "Жанна", age: 40))

var filterProfiles = profiles.filter() {element in element.age > 18}
filterProfiles.forEach { print($0.toText) }

profiles[3]
